import { Component, OnInit } from '@angular/core';
import { ProductService } from '../services/product.service';

@Component({
  selector: 'app-find-one',
  templateUrl: './find-one.component.html',
  styleUrls: ['./find-one.component.css']
})
export class FindOneComponent implements OnInit {

  constructor(private productService: ProductService) { }

  ngOnInit() {
    //this.productService.getProductDetails(productId:Number).subscribe()
  }

}
