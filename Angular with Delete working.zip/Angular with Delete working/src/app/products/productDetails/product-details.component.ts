import { Component, OnInit } from '@angular/core';
import { Product } from '../product';
import { ActivatedRoute, Router } from '@angular/router';
import { ProductService } from 'src/app/services/product.service';

@Component({
  selector: 'app-product-details',
  templateUrl: './product-details.component.html',
  styleUrls: ['./product-details.component.css']
})
export class ProductDetailsComponent implements OnInit {
  pageTitle: string = 'Product Detail';
  errorMessage : string;
  product: Product;

  constructor(private route:ActivatedRoute,private router:Router,private productService:ProductService) { }

  ngOnInit() {
    const id = this.route.snapshot.paramMap.get('id');
    const productId= +id;
    this.productService.getProductDetails(productId).subscribe(
      product=>{
        this.product=product;
      },
      errorMessage=>{
        this.errorMessage = errorMessage;
      }
    );
  }
  public navigateBack():void{
    this.router.navigate(['/products']);
  }
}
