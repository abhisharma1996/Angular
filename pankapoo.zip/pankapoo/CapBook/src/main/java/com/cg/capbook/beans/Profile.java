package com.cg.capbook.beans;

import java.util.List;

import javax.persistence.Embeddable;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;


@Entity
public class Profile {

	private String name;
	private String gender;
	private String phoneNo;
	private String dateOfBirth;
	private String bio;
	@Id
	private String emailId;
	@OneToMany
	private List<Album> albumList;
	@OneToMany
	private List<Profile> friendList;
	private List<Post> postList;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getPhoneNo() {
		return phoneNo;
	}
	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}
	public String getDateOfBirth() {
		return dateOfBirth;
	}
	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	public String getBio() {
		return bio;
	}
	public void setBio(String bio) {
		this.bio = bio;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public List<Album> getAlbumList() {
		return albumList;
	}
	public void setAlbumList(List<Album> albumList) {
		this.albumList = albumList;
	}
	public List<Profile> getFriendList() {
		return friendList;
	}
	public void setFriendList(List<Profile> friendList) {
		this.friendList = friendList;
	}
	public List<Post> getPostList() {
		return postList;
	}
	public void setPostList(List<Post> postList) {
		this.postList = postList;
	}
	public Profile(String name, String gender, String phoneNo, String dateOfBirth, String bio, String emailId,
			List<Album> albumList, List<Profile> friendList, List<Post> postList) {
		super();
		this.name = name;
		this.gender = gender;
		this.phoneNo = phoneNo;
		this.dateOfBirth = dateOfBirth;
		this.bio = bio;
		this.emailId = emailId;
		this.albumList = albumList;
		this.friendList = friendList;
		this.postList = postList;
	}
	public Profile() {
		super();
	}

	
	
}
