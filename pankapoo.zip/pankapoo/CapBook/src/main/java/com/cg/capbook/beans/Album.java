package com.cg.capbook.beans;

import java.util.List;

import javax.persistence.Embeddable;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
@Entity
public class Album {
	@Id
	private int albumId;
	private String albumName;
	@OneToMany
	private List<Photo> photos;
	
	

}
