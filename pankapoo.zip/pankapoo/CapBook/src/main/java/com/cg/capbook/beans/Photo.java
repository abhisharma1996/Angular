package com.cg.capbook.beans;

import java.util.List;

import javax.persistence.Id;

public class Photo {
	@Id
	private int photoId;
	private String linkToPhoto;
	private  int like;
	private int dislike;
	private List<String> comments;

}
