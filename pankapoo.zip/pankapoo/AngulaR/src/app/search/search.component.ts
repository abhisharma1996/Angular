import { Component, OnInit } from '@angular/core';
import { User } from '../user/user';
import { ActivatedRoute, Router } from '@angular/router';
import { CapbookService } from '../services/capbook.service';
import { Profile } from '../user/profile/profile';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {

  searchBox:string="Search Box";
  constructor(private route :ActivatedRoute,private router : Router,private service : CapbookService) { }

  error : string;
  msg : string;
  profile:Profile={
      name:'',
      gender:'',
      phoneNo:'',
      dateOfBirth:'',
      bio:'',
      emailId:''
    }
  
  user2:User={
    userName:'',
    password:'',
    profile:{
      name:'',
      gender:'',
      phoneNo:'',
      dateOfBirth:'',
      bio:'',
      emailId:''
    }
  } 

  profileList:Profile[];
  ngOnInit() {
   
  }

  public searchUser(){
    this.service.getAllProfiles(this.profile.name).subscribe(
      profiles =>{
        this.profileList = profiles;
        //this.router.navigate(['/search']);
    },
    errorMessage=>{
    
      this.error="user not found!";
    }); 
  }
}
