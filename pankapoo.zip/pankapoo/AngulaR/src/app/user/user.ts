import { Profile } from "./profile/profile";


export interface User {
    userName : string,
    password : string,
    profile : Profile
}
