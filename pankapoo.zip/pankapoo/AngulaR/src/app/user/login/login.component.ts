import { Component, OnInit } from '@angular/core';
import { Route } from '@angular/compiler/src/core';
import { ActivatedRoute, Router } from '@angular/router';
import { CapbookService } from 'src/app/services/capbook.service';
import { User } from '../user';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor(private route :ActivatedRoute,private router : Router,private service : CapbookService ) { }

  error : string;
  user:User={
    userName:'',
    password:'',
    profile:{
      name:'',
      gender:'',
      phoneNo:'',
      dateOfBirth:'',
      bio:'',
      emailId:''
    }
  } 

  ngOnInit() {    
  }

  public login(){

    this.service.loginUser(this.user.userName,this.user.password).subscribe(
      user =>{
      this.user = user;
      console.log("hello1");
      
    },
    errorMessage=>{
      this.error=errorMessage;
    });
    this.router.navigate(['/profile',{"username":this.user.userName}])
  }
}
