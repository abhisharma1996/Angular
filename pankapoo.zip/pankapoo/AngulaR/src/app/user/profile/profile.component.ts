import { Component, OnInit } from '@angular/core';
import { User } from '../user';
import { CapbookService } from 'src/app/services/capbook.service';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {

  constructor(private route :ActivatedRoute,private router : Router,private service : CapbookService) { }
error:string;
flag : string='zero';

  user:User={
    userName:'',
    password:'',
    profile:{
      name:'',
      gender:'',
      phoneNo:'',
      dateOfBirth:'',
      bio:'',
      emailId:''
    }
  } 

  ngOnInit() {
    const username=this.route.snapshot.paramMap.get('username');
       
        this.service.getUserDetails(username).subscribe(user1=>{
          this.user = user1;
        },
        errorMessage=>{
          this.error = errorMessage;
        });
        
      }

    public editProfile(){
      this.flag='one';
      this.router.navigate(['/profile',{"username":this.user.userName}])
    }

    public updateProfile(){
      this.flag='zero';
      this.service.updateProfile(this.user).subscribe(user1=>{
        this.user = user1;
      },
      errorMessage=>{
        this.error = errorMessage;
      });
    }
}
