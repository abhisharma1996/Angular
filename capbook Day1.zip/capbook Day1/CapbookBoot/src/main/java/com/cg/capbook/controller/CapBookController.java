package com.cg.capbook.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.capbook.beans.Profile;
import com.cg.capbook.beans.Users;
import com.cg.capbook.dao.UsersDAO;
import com.cg.capbook.exceptions.UserNotFoundException;
import com.cg.capbook.services.CapBookServices;


@CrossOrigin
@RestController
public class CapBookController {
	
	@Autowired
	CapBookServices service;
	
	Users temp;
	
	@RequestMapping("/hello")
	public ResponseEntity<String> sayHello(){
		return new ResponseEntity<String>("hi yoyo",HttpStatus.OK);
	}
	
	@RequestMapping(value="/acceptUserDetails",method=RequestMethod.POST,
			consumes=MediaType.APPLICATION_JSON_VALUE,headers="Accept=application/json")
	public ResponseEntity<Users> acceptUserDetails(@RequestBody Users user){
		System.out.println("hello");
		System.out.println(user);
		user=service.acceptUserDetails(user);
		temp=user;
		return new ResponseEntity<Users>(user,HttpStatus.OK);
	}
	
	@RequestMapping(value="/loginUser",method=RequestMethod.POST,
			consumes=MediaType.APPLICATION_JSON_VALUE,headers="Accept=application/json")
	public ResponseEntity<Users> loginUser(@RequestParam("userName") String userName,@RequestParam("password") String password){
		return new ResponseEntity<Users>(service.loginUser(userName, password),HttpStatus.OK);
	}
	
	@RequestMapping(value="/getAllUsers",method=RequestMethod.GET,
			consumes=MediaType.APPLICATION_JSON_VALUE,headers="Accept=application/json")
	public ResponseEntity<List<Users>> getAllUsers(){
		return new ResponseEntity<List<Users>>(service.getAllUserDetails(),HttpStatus.OK);
	}
	@RequestMapping(value="/getAllProfiles",method=RequestMethod.GET,
			produces=MediaType.APPLICATION_JSON_VALUE,headers="Accept=application/json")
	public ResponseEntity<List<Profile>> getAllProfiles(@RequestParam("name") String name){
		System.out.println("85");
		return new ResponseEntity<List<Profile>>(service.getAllProfiles(name),HttpStatus.OK);
	}
	@RequestMapping(value="/getUserDetails",method=RequestMethod.GET,
			produces=MediaType.APPLICATION_JSON_VALUE,headers="Accept=application/json")
	public ResponseEntity<Users> getUserDetails(@RequestParam("userName") String userName) throws UserNotFoundException{//throws Exception{
		System.out.println(1);
		return new ResponseEntity<Users>(service.getUserDetails(userName),HttpStatus.OK);
	}
}
