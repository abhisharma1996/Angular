package com.cg.capbook.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.capbook.beans.Profile;
import com.cg.capbook.beans.Users;
import com.cg.capbook.dao.ProfileDAO;
import com.cg.capbook.dao.UsersDAO;
import com.cg.capbook.exceptions.UserNotFoundException;

@Component("service")
public class CapBookServicesImpl implements CapBookServices {

	@Autowired
	UsersDAO usersDAO;
	@Autowired
	ProfileDAO profileDAO;
	@Override
	public Users acceptUserDetails(Users user) {
			return usersDAO.save(user);
	}

	@Override
	public Profile addUserProfile(Profile profile) {
		return profileDAO.save(profile);
	}

	@Override
	public List<Users> getAllUserDetails() {
		return usersDAO.findAll();
	}

	@Override
	public Users loginUser(String userName, String password) {
		Users user = usersDAO.findById(userName).get();
		if(user.getPassword().equals(password))
			return user;
		return null;
	}

	@Override
	public Users getUserDetails(String userName) throws UserNotFoundException {
		System.out.println(2);
		System.out.println(userName);
		Users user = usersDAO.findById(userName).orElse(null); 
		if(user==null)
			System.out.println("IT IS NULL");
	
		return usersDAO.findById(userName).get();
	}

	@Override
	public List<Profile> getAllProfiles(String name) {
		System.out.println(name);
		return profileDAO.getProfiles(name);
	}

	/*@Override
	public Users addFriendProfile(Profile profile, Users user) {
		Users userFi = usersDAO.findById(user.getUserName()).get();
		if(profile.getEmailId()==null)
		userFi.addFriend(profile);
		return usersDAO.save(userFi);
	}*/

}
