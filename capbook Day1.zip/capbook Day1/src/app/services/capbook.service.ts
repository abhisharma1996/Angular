import { Injectable } from '@angular/core';
import { User } from '../user/user';
import { HttpHeaders, HttpClient,HttpParams,HttpErrorResponse } from '@angular/common/http';
import { Observable, from, throwError } from 'rxjs';
import { map,catchError} from 'rxjs/operators'
import { Profile } from '../user/profile/profile';

@Injectable({
  providedIn: 'root'
})
export class CapbookService {

  user:User;
  private headers = new HttpHeaders({'Content-Type': 'application/json'});


  constructor(private httpClient:HttpClient){}
 
  public acceptUserDetails(user: User):Observable<User>{      
     return  this.httpClient.post<User>
    ("http://localhost:5558/acceptUserDetails",user, {headers: this.headers}).
    pipe(catchError(this.handleError));
  }

  public loginUser(userName:string,password:string):Observable<User>{  
    let params = new HttpParams();
    params = params.set('userName',userName.toString());
    params = params.set('password',password.toString());    
    return  this.httpClient.get<User>
   ("http://localhost:5558/loginUser",{params:params}).
   pipe(catchError(this.handleError));
 }


  // public getUserDetails(userName:string):Observable<User>{
  //    let params=new HttpParams();
  //    params=params.set('userName',userName.toString());
  //     return  this.httpClient.get<User>
  //     ("http://localhost:5558/",{params:params}).
  //     pipe(catchError(this.handleError));
  //   }

  public getUserDetails(userName:string):Observable<User>{  
    let params = new HttpParams();
    params = params.set('userName',userName.toString());    
    return  this.httpClient.get<User>
   ("http://localhost:5558/getUserDetails",{params:params}).
   pipe(catchError(this.handleError));
 }

 public getAllProfiles(name:string):Observable<Profile[]>{  
  let params = new HttpParams();
  params = params.set('name',name.toString());    
  return  this.httpClient.get<Profile[]>
 ("http://localhost:5558/getAllProfiles",{params:params}).
 pipe(catchError(this.handleError));
}
  
  private handleError(error:any){
    if(error instanceof ErrorEvent){
      console.error('1 An ErrorEvent occurred:',error.error.message);
      return throwError(error.error.message);
    }else if(error instanceof HttpErrorResponse ){
      console.error(`2 Backend returned code ${error.status},body was: ${error.message}`);
      return throwError(`Backend returned code ${error.status},body was: ${error.message}`);
    }
    else if(error instanceof TypeError){
      console.error(`3 TypeError has occured ${error.message}, body was ${error.stack}`)
      return throwError(`TypeError has occured ${error.message}, body was ${error.stack}`)
    }
  }

}
