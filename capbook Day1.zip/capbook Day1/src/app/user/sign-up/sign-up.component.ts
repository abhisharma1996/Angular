import { Component, OnInit } from '@angular/core';
import { User } from '../user';
import { ActivatedRoute, Router } from '@angular/router';
import { CapbookService } from 'src/app/services/capbook.service';
import { THIS_EXPR } from '@angular/compiler/src/output/output_ast';

@Component({
  selector: 'app-sign-up',
  templateUrl: './sign-up.component.html',
  styleUrls: ['./sign-up.component.css']
})
export class SignUpComponent implements OnInit {

  error : string;
  user:User={
    userName:'',
    password:'',
    profile:{
      name:'',
      gender:'',
      phoneNo:'',
      dateOfBirth:'',
      bio:'',
      emailId:''
    }
  }

  constructor(private route:ActivatedRoute,private router : Router,private service: CapbookService) { }

  ngOnInit() {
  }
  public signUp() : void{
    this.service.acceptUserDetails(this.user).subscribe(user1 =>{
      this.user = user1;
    },
    errorMessage=>{
      this.error=errorMessage;
    });
    this.router.navigate(['/profile'])
  }

}
