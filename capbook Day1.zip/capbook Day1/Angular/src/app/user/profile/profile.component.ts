import { Component, OnInit } from '@angular/core';
import { User } from '../user';
import { CapbookService } from 'src/app/services/capbook.service';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {

  constructor(private route :ActivatedRoute,private router : Router,private service : CapbookService) { }
error:string;

  user:User={
    userName:'',
    password:'',
    profile:{
      name:'',
      gender:'',
      phoneNo:'',
      dateOfBirth:'',
      bio:'',
      emailId:''
    }
  } 

  ngOnInit() {
    const username=this.route.snapshot.paramMap.get('username');
       //const userName=+username;
        this.service.getUserDetails(username).subscribe(user1=>{
          this.user = user1;
        },
        errorMessage=>{
          this.error = errorMessage;
        });
        
      }

}
